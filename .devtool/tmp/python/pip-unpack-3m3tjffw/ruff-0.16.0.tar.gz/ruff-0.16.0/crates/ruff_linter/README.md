<!-- This file is generated. DO NOT EDIT -->

# ruff_linter

This crate is an internal component of [Ruff](https://crates.io/crates/ruff). The Rust API exposed
here is unstable and will have frequent breaking changes.

This version (0.16.0) is a component of [Ruff 0.16.0](https://crates.io/crates/ruff/0.16.0). The
source can be found [here](https://github.com/astral-sh/ruff/blob/0.16.0/crates/ruff_linter).

See Ruff's [crate versioning policy](https://docs.astral.sh/ruff/versioning/#crate-versioning) for
details on versioning.
