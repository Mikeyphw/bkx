"""Tests for CLI layer."""
