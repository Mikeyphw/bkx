"""Tests for feature contract - Polish & Parity

Tests cover:
- 11A: TCSS Theme Tuning
- 11B: Animations & Transitions
- 11C: Accessibility
- 11D: Documentation/Help
"""

from __future__ import annotations

from pathlib import Path

import pytest


def get_tui_css_dir():
    """Get the path to the TUI CSS directory."""
    return Path(__file__).resolve().parent.parent.parent / "src" / "bkx" / "tui" / "css"


def get_tui_css_path(filename: str) -> Path:
    """Get the path to a specific CSS file."""
    return get_tui_css_dir() / filename


class TestAnimationsStep11B:
    """Tests for animation classes."""

    def test_animation_css_exists(self) -> None:
        """Test that animation CSS file exists."""
        css_path = get_tui_css_path("animations.tcss")
        assert css_path.exists(), f"animations.tcss not found at {css_path}"

    def test_animation_classes_exist(self) -> None:
        """Test that animation classes are defined."""
        css_path = get_tui_css_path("animations.tcss")
        assert css_path.exists()

        content = css_path.read_text()

        # Check for key animation classes
        assert "bkx-animate-fade-in" in content
        assert "bkx-animate-pulse" in content
        assert "bkx-animate-spin" in content
        assert "bkx-transition-fast" in content
        assert "bkx-transition-normal" in content

    def test_keyframes_defined(self) -> None:
        """Test that CSS keyframes are defined."""
        css_path = get_tui_css_path("animations.tcss")
        content = css_path.read_text()

        # Check for keyframe definitions
        assert "@keyframes bkx-fade-in" in content
        assert "@keyframes bkx-pulse" in content
        assert "@keyframes bkx-spin" in content

    def test_reduced_motion_support(self) -> None:
        """Test reduced motion media query exists."""
        css_path = get_tui_css_path("animations.tcss")
        content = css_path.read_text()

        assert "@media (prefers-reduced-motion" in content
        assert "animation-duration: 0.01ms" in content


class TestLoadingSpinnerStep11B:
    """Tests for loading spinner widget."""

    def test_spinner_creation(self) -> None:
        """Test loading spinner can be created."""
        from bkx.tui.widgets.loading_spinner import LoadingSpinner

        spinner = LoadingSpinner(message="Loading...")
        assert spinner.message == "Loading..."
        assert spinner._spinner_type == "spinner"

    def test_spinner_frames(self) -> None:
        """Test spinner animation frames."""
        from bkx.tui.widgets.loading_spinner import LoadingSpinner

        spinner = LoadingSpinner(message="Loading...")
        assert len(spinner.SPINNER_FRAMES) > 0
        assert len(spinner.DOTS_FRAMES) > 0
        assert len(spinner.BAR_FRAMES) > 0

    def test_dots_creation(self) -> None:
        """Test progress dots can be created."""
        from bkx.tui.widgets.loading_spinner import ProgressDots

        dots = ProgressDots(message="Working")
        assert dots._message == "..."

    def test_skeleton_loader_creation(self) -> None:
        """Test skeleton loader can be created."""
        from bkx.tui.widgets.loading_spinner import SkeletonLoader

        skeleton = SkeletonLoader(width=20, height=3)
        assert skeleton._width == 20
        assert skeleton._height == 3

    def test_status_indicator(self) -> None:
        """Test status indicator can be created."""
        from bkx.tui.widgets.loading_spinner import StatusIndicator

        indicator = StatusIndicator(status="success", message="Done!")
        assert indicator._status == "success"
        assert indicator._message == "Done!"

    def test_status_icons(self) -> None:
        """Test status indicator icons."""
        from bkx.tui.widgets.loading_spinner import StatusIndicator

        assert "success" in StatusIndicator.ICONS
        assert "error" in StatusIndicator.ICONS
        assert "warning" in StatusIndicator.ICONS
        assert "loading" in StatusIndicator.ICONS


class TestHelpOverlayStep11D:
    """Tests for help overlay."""

    def test_help_overlay_creation(self) -> None:
        """Test help overlay can be created (without mikomn dependency)."""
        from bkx.tui.overlays.help_overlay import BkxHelpOverlay

        overlay = BkxHelpOverlay(bindings=[])
        assert overlay is not None
        assert hasattr(overlay, "compose")
        assert hasattr(overlay, "get_shortcuts_text")
        assert hasattr(overlay, "get_navigation_text")
        assert hasattr(overlay, "get_tips_text")

    def test_shortcuts_reference(self) -> None:
        """Test shortcuts reference widget."""
        from bkx.tui.overlays.help_overlay import ShortcutsReference

        ref = ShortcutsReference()
        assert ref is not None
        assert hasattr(ref, "compose")

    def test_page_help(self) -> None:
        """Test page help dictionary."""
        from bkx.tui.overlays.help_overlay import PAGE_HELP, get_page_help

        # Check key pages exist
        assert "backup" in PAGE_HELP
        assert "archive" in PAGE_HELP
        assert "restore" in PAGE_HELP

        # Check function works
        assert "backup" in get_page_help("backup")
        assert "No help" in get_page_help("unknown")

    def test_help_css_exists(self) -> None:
        """Test help CSS file exists."""
        css_path = get_tui_css_path("help.tcss")
        assert css_path.exists(), f"help.tcss not found at {css_path}"

        content = css_path.read_text()
        assert "bkx-help-overlay" in content
        assert "shortcuts-reference" in content

    def test_help_overlay_bindings(self) -> None:
        """Test help overlay has correct bindings."""
        from bkx.tui.overlays.help_overlay import BkxHelpOverlay

        overlay = BkxHelpOverlay(bindings=[])
        assert hasattr(overlay, "BINDINGS")
        assert ("escape", "close", "Close") in overlay.BINDINGS

    def test_help_overlay_get_text_methods(self) -> None:
        """Test help overlay text generation methods."""
        from bkx.tui.overlays.help_overlay import BkxHelpOverlay

        overlay = BkxHelpOverlay(bindings=[])

        # Check that text methods return strings
        shortcuts = overlay.get_shortcuts_text()
        assert isinstance(shortcuts, str)
        assert "Keyboard Shortcuts" in shortcuts
        assert "Navigation" in shortcuts

        nav = overlay.get_navigation_text()
        assert isinstance(nav, str)
        assert "Navigation Guide" in nav

        tips = overlay.get_tips_text()
        assert isinstance(tips, str)
        assert "Tips & Tricks" in tips


class TestAccessibilityStep11C:
    """Tests for accessibility features."""

    def test_accessibility_css_exists(self) -> None:
        """Test accessibility CSS file exists."""
        css_path = get_tui_css_path("accessibility.tcss")
        assert css_path.exists(), f"accessibility.tcss not found at {css_path}"

        content = css_path.read_text()

        # Check for accessibility features
        assert "contrast" in content.lower() or "WCAG" in content
        assert "focus" in content.lower()
        assert "@media" in content

    def test_focus_styles(self) -> None:
        """Test focus styles are defined."""
        css_path = get_tui_css_path("accessibility.tcss")
        content = css_path.read_text()

        assert "*:focus" in content or "focus" in content

    def test_reduced_motion_css(self) -> None:
        """Test reduced motion CSS exists."""
        css_path = get_tui_css_path("accessibility.tcss")
        content = css_path.read_text()

        assert "prefers-reduced-motion" in content

    def test_high_contrast_mode(self) -> None:
        """Test high contrast mode is defined."""
        css_path = get_tui_css_path("accessibility.tcss")
        content = css_path.read_text()

        assert ".high-contrast" in content

    def test_aria_equivalents(self) -> None:
        """Test aria-equivalent classes exist."""
        css_path = get_tui_css_path("accessibility.tcss")
        content = css_path.read_text()

        # Check for screen reader classes
        assert "bkx-sr-only" in content or "sr-only" in content


class TestThemeTuningStep11A:
    """Tests for theme tuning."""

    def test_shell_css_exists(self) -> None:
        """Test shell CSS exists and has layout styles."""
        css_path = get_tui_css_path("shell.tcss")
        assert css_path.exists(), f"shell.tcss not found at {css_path}"

        content = css_path.read_text()

        # Check for key layout elements
        assert ".bkx-shell" in content

    def test_overlays_css_exists(self) -> None:
        """Test overlays CSS exists."""
        css_path = get_tui_css_path("overlays.tcss")
        assert css_path.exists(), f"overlays.tcss not found at {css_path}"

    def test_form_styles(self) -> None:
        """Test form styling exists."""
        css_path = get_tui_css_path("shell.tcss")
        content = css_path.read_text()

        # Check for form-related styles
        assert ".form-input" in content or "form-input" in content


class TestIntegrationStep11:
    """Integration tests for feature contract features."""

    def test_all_css_files_loaded(self) -> None:
        """Test that all feature contract CSS files can be loaded."""
        css_dir = get_tui_css_dir()

        # feature contract files
        step11_files = [
            "animations.tcss",
            "help.tcss",
            "accessibility.tcss",
        ]

        for filename in step11_files:
            path = css_dir / filename
            assert path.exists(), f"CSS file {filename} does not exist at {path}"
            content = path.read_text()
            assert len(content) > 0, f"CSS file {filename} is empty"

    def test_widget_imports(self) -> None:
        """Test that all feature contract widgets can be imported."""
        # Loading spinner widgets
        from bkx.tui.widgets.loading_spinner import (
            LoadingSpinner,
            ProgressDots,
            SkeletonLoader,
            StatusIndicator,
        )

        assert LoadingSpinner is not None
        assert ProgressDots is not None
        assert SkeletonLoader is not None
        assert StatusIndicator is not None

        # Help overlay components (without mikomn)
        from bkx.tui.overlays.help_overlay import (
            BkxHelpOverlay,
            ShortcutsReference,
            get_page_help,
        )

        assert BkxHelpOverlay is not None
        assert ShortcutsReference is not None
        assert callable(get_page_help)

    def test_animations_dont_crash(self) -> None:
        """Test that animation widgets don't crash on basic operations."""
        from bkx.tui.widgets.loading_spinner import (
            LoadingSpinner,
            ProgressDots,
            StatusIndicator,
        )

        # Create widgets
        spinner = LoadingSpinner(message="Test")
        assert spinner is not None

        dots = ProgressDots(message="Test")
        assert dots is not None

        status = StatusIndicator(status="info")
        assert status is not None

    def test_help_overlay_text_methods(self) -> None:
        """Test help overlay text generation methods return valid content."""
        from bkx.tui.overlays.help_overlay import BkxHelpOverlay

        overlay = BkxHelpOverlay(bindings=[])

        # Check that text methods return valid content
        shortcuts = overlay.get_shortcuts_text()
        assert len(shortcuts) > 100  # Should have substantial content
        assert "Ctrl+K" in shortcuts
        assert "/" in shortcuts

        nav = overlay.get_navigation_text()
        assert len(nav) > 50
        assert "Sidebar" in nav

        tips = overlay.get_tips_text()
        assert len(tips) > 50
        assert "Search" in tips


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
